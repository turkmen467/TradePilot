TradePilot Mobil Demo v0.2

Dosyalar:
- index.html: tek dosyalık mobil web prototipi

Kullanım:
1. index.html dosyasını GitHub deposundaki mevcut index.html dosyasının yerine koyup commit edebilirsin.
2. GitHub Pages güncellendikten sonra siteni yenile.

Notlar:
- BTC/USDT ve ETH/USDT için Binance herkese açık API'sinden fiyat almayı dener.
- Bağlantı başarısız olursa "Veri alınamadı" gösterir; örnek fiyatla canlı veri varmış gibi davranmaz.
- Sanal AL/SAT kayıtlarıdır; gerçek emir göndermez.
- Sinyaller işlem tavsiyesi değildir ve bu sürümde gerçek sinyal algoritması yoktur.
